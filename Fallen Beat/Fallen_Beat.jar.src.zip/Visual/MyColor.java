/*    */ package Visual;
/*    */ 
/*    */ import java.awt.Color;
/*    */ 
/*    */ public class MyColor
/*    */ {
/*  7 */   public Color white = new Color(16187135);
/*  8 */   public Color yellow = new Color(16772468);
/*  9 */   public Color brown = new Color(11884100);
/* 10 */   public Color gray = new Color(5529446);
/* 11 */   public Color blue = new Color(5208751);
/*    */ }


/* Location:              /home/user/ais3/Fallen Beat/Fallen_Beat/Fallen_Beat.jar!/Visual/MyColor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */