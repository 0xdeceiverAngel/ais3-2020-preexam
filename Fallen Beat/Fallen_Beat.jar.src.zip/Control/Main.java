/*    */ package Control;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Main
/*    */ {
/*    */   public static void main(String[] args) {
/*  8 */     Frame fallen_beat = new Frame("Fallen Beat");
/*  9 */     fallen_beat.setSize(1280, 720);
/* 10 */     fallen_beat.setDefaultCloseOperation(3);
/* 11 */     fallen_beat.setLocationRelativeTo(null);
/* 12 */     fallen_beat.setResizable(false);
/* 13 */     fallen_beat.setVisible(true);
/*    */   }
/*    */ }


/* Location:              /home/user/ais3/Fallen Beat/Fallen_Beat/Fallen_Beat.jar!/Control/Main.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */